import openpyxl
import time
import numpy as np

class Cpu_Reader:
    def __init__(self,input_num):
        # 엑셀 파일 열기
        self.wb = openpyxl.load_workbook('C:/Users/정현제/Pictures/Desktop/230326/intersection.xlsx')

        self.Car_Cpu = self.wb['cpu']

        # 시작 열의 인덱스
        self.start_col = 2

        self.start_row = input_num

        # 결과를 저장할 리스트

        self.result3_list = []

    def get_result_list(self):
        # 지정한 행의 값을 가져와서 리스트에 추가
        row_values = []
        for cell in self.Car_Cpu[self.start_row]:
            if cell.value is not None:
                row_values.append(cell.value)

        # 결과 리스트에 추가
        self.result3_list.append(row_values)

        # 결과 리스트 반환
        return row_values
